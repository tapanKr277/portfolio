import React from 'react'

const Project = ({image,l1,p,date,role,info}) => {
  return (
    <div>
        <div>
            
        </div>
    </div>
  )
}

export default Project